package androidx.core.util;
/* loaded from: classes.dex */
public interface Consumer<T> {
    void accept(T t);
}
