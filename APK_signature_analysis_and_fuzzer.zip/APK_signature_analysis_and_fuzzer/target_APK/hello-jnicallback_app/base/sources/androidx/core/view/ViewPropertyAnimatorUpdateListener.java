package androidx.core.view;

import android.view.View;
/* loaded from: classes.dex */
public interface ViewPropertyAnimatorUpdateListener {
    void onAnimationUpdate(View view);
}
