package androidx.lifecycle;
/* loaded from: classes.dex */
public interface Observer<T> {
    void onChanged(T t);
}
