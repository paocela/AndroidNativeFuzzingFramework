package androidx.lifecycle;
/* loaded from: classes.dex */
public abstract class ViewModel {
    public void onCleared() {
    }
}
